import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Heart, ShoppingBag, Zap } from 'lucide-react'
import { cn, formatCurrency, formatCountdown } from '../../lib/utils'
import { Avatar } from '../shared/Avatar'

export function ProductCard({ product }) {
  const [wishlisted, setWishlisted] = useState(false)
  const isDropItem = !!product.drop_at
  const isOutOfStock = product.stock === 0 && !product.unlimited_stock && !isDropItem

  return (
    <div className="bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-md transition-shadow">
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        {product.images?.[0]
          ? <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
          : <div className="w-full h-full flex items-center justify-center text-gray-300">
              <ShoppingBag size={40} />
            </div>
        }
        {/* Wishlist */}
        <button
          onClick={() => setWishlisted(w => !w)}
          className="absolute top-2 right-2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center shadow-sm"
        >
          <Heart size={16} className={wishlisted ? 'fill-red-500 text-red-500' : 'text-gray-400'} />
        </button>
        {/* Drop badge */}
        {isDropItem && (
          <div className="absolute top-2 left-2 flex items-center gap-1 bg-[#C4622D] text-white rounded-full px-2 py-0.5">
            <Zap size={10} />
            <span className="text-[10px] font-bold">DROP</span>
          </div>
        )}
        {/* Out of stock */}
        {isOutOfStock && (
          <div className="absolute inset-0 bg-white/70 flex items-center justify-center">
            <span className="text-xs font-bold text-gray-500 bg-white rounded-full px-3 py-1 shadow">Sold Out</span>
          </div>
        )}
      </div>

      <div className="p-3">
        <Link to={`/brand/${product.brand?.slug}`} className="flex items-center gap-1.5 mb-1.5">
          <Avatar src={product.brand?.logo_url} name={product.brand?.name} size="xs" />
          <span className="text-xs text-gray-400">{product.brand?.name}</span>
        </Link>

        <p className="font-semibold text-sm text-gray-900 line-clamp-2 mb-2">{product.name}</p>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-gray-900">{formatCurrency(product.price)}</span>
            {product.compare_price && (
              <span className="text-xs text-gray-400 line-through">{formatCurrency(product.compare_price)}</span>
            )}
          </div>
          {!isOutOfStock && (
            <button className="w-8 h-8 bg-[#C4622D] rounded-xl flex items-center justify-center hover:bg-[#a85225] transition-colors">
              <ShoppingBag size={14} className="text-white" />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
