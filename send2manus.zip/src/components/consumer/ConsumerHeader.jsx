import { Link } from 'react-router-dom'
import { Bell, Search, User } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import { Avatar } from '../shared/Avatar'

export function ConsumerHeader() {
  const { profile } = useAuth()

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-gray-100">
      <div className="flex items-center justify-between px-4 py-3">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-1.5">
          <div className="w-8 h-8 rounded-xl bg-[#C4622D] flex items-center justify-center">
            <span className="text-white font-bold text-sm">K</span>
          </div>
          <span className="font-bold text-lg text-[#1A3A2A] tracking-tight">kitakakis</span>
        </Link>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <Link to="/search" className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-gray-100 text-gray-600 transition-colors">
            <Search size={20} />
          </Link>
          <Link to="/notifications" className="relative w-9 h-9 flex items-center justify-center rounded-xl hover:bg-gray-100 text-gray-600 transition-colors">
            <Bell size={20} />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#C4622D] rounded-full" />
          </Link>
          {profile
            ? <Link to="/profile">
                <Avatar src={profile.avatar_url} name={profile.display_name} size="sm" />
              </Link>
            : <Link to="/auth/login" className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-gray-100 text-gray-600">
                <User size={20} />
              </Link>
          }
        </div>
      </div>
    </header>
  )
}
