import { useEffect, useRef, useState } from 'react'
import { formatDate, formatCurrency } from '../../lib/utils'
import { downloadICS, googleCalendarURL } from '../../lib/calendar'
import { CalendarPlus, X, MapPin, Clock, Users } from 'lucide-react'

// Singapore center
const SG_CENTER = { lng: 103.8198, lat: 1.3521 }
const SG_ZOOM = 11.5

export function EventMap({ events }) {
  const mapContainer = useRef(null)
  const mapRef = useRef(null)
  const [selected, setSelected] = useState(null)
  const [mapLoaded, setMapLoaded] = useState(false)
  const [mapError, setMapError] = useState(false)

  useEffect(() => {
    if (mapRef.current || !mapContainer.current) return

    let map
    async function initMap() {
      try {
        const mapboxgl = (await import('mapbox-gl')).default
        await import('mapbox-gl/dist/mapbox-gl.css')

        // Use a free/demo token or env var
        mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_TOKEN || ''

        if (!mapboxgl.accessToken) {
          setMapError(true)
          return
        }

        map = new mapboxgl.Map({
          container: mapContainer.current,
          style: 'mapbox://styles/mapbox/light-v11',
          center: [SG_CENTER.lng, SG_CENTER.lat],
          zoom: SG_ZOOM,
          attributionControl: false,
        })

        map.addControl(new mapboxgl.NavigationControl(), 'top-right')

        map.on('load', () => {
          setMapLoaded(true)

          events.forEach(event => {
            if (!event.lat || !event.lng) return
            const now = new Date()
            const start = new Date(event.starts_at)
            const end = event.ends_at ? new Date(event.ends_at) : null
            const isHappening = start <= now && (!end || end >= now)
            const isUpcoming = start > now

            const el = document.createElement('div')
            el.className = 'event-map-pin'
            el.style.cssText = `
              width: 32px; height: 32px; border-radius: 50%;
              display: flex; align-items: center; justify-content: center;
              cursor: pointer; transition: transform 0.15s;
              border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.2);
              background: ${isHappening ? '#C4622D' : isUpcoming ? '#1A3A2A' : '#9CA3AF'};
            `
            el.innerHTML = `<span style="color:white;font-size:10px;font-weight:700;">${isHappening ? '!' : formatDate(event.starts_at, 'd')}</span>`
            el.addEventListener('mouseenter', () => { el.style.transform = 'scale(1.3)' })
            el.addEventListener('mouseleave', () => { el.style.transform = 'scale(1)' })
            el.addEventListener('click', () => setSelected(event))

            // Pulse ring for live events
            if (isHappening) {
              const pulse = document.createElement('div')
              pulse.style.cssText = `
                position: absolute; width: 44px; height: 44px; border-radius: 50%;
                background: rgba(196,98,45,0.3); z-index: -1;
                animation: mapPulse 2s ease-in-out infinite;
                top: -6px; left: -6px;
              `
              el.style.position = 'relative'
              el.appendChild(pulse)
            }

            new mapboxgl.Marker({ element: el })
              .setLngLat([event.lng, event.lat])
              .addTo(map)
          })
        })

        mapRef.current = map
      } catch (err) {
        console.warn('Map init failed:', err)
        setMapError(true)
      }
    }

    initMap()
    return () => { if (map) map.remove() }
  }, [events])

  // Fallback map (no token)
  if (mapError) {
    return (
      <div className="relative rounded-3xl overflow-hidden border border-gray-200 bg-gradient-to-br from-green-50 to-teal-50">
        <div className="h-72 flex flex-col items-center justify-center gap-2 px-6">
          <MapPin size={32} className="text-[#1A3A2A]" />
          <p className="font-bold text-gray-700 text-sm">Event Map</p>
          <p className="text-xs text-gray-500 text-center">
            Add VITE_MAPBOX_TOKEN to .env.local to enable the interactive map.
          </p>

          {/* Static pin list fallback */}
          <div className="w-full mt-3 space-y-1.5">
            {events.map(e => {
              const isLive = new Date(e.starts_at) <= new Date() && (!e.ends_at || new Date(e.ends_at) >= new Date())
              return (
                <button
                  key={e.id}
                  onClick={() => setSelected(e)}
                  className="w-full flex items-center gap-2 bg-white rounded-xl px-3 py-2 text-left hover:shadow-sm transition-shadow"
                >
                  <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${isLive ? 'bg-[#C4622D] animate-pulse' : 'bg-[#1A3A2A]'}`} />
                  <span className="text-sm font-medium text-gray-800 flex-1 truncate">{e.title}</span>
                  <span className="text-xs text-gray-400">{formatDate(e.starts_at, 'MMM d')}</span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Selected event popup */}
        {selected && <EventPopup event={selected} onClose={() => setSelected(null)} />}
      </div>
    )
  }

  return (
    <div className="relative rounded-3xl overflow-hidden border border-gray-200">
      {/* Inject pulse animation */}
      <style>{`@keyframes mapPulse { 0%,100% { transform: scale(1); opacity: 0.4; } 50% { transform: scale(1.5); opacity: 0; } }`}</style>

      <div ref={mapContainer} className="h-72 w-full" />

      {/* Legend */}
      <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm rounded-xl px-3 py-2 shadow-sm">
        <div className="flex items-center gap-3 text-[10px] font-semibold">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#C4622D] animate-pulse" />Happening Now</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#1A3A2A]" />Coming Soon</span>
        </div>
      </div>

      {/* Selected event popup */}
      {selected && <EventPopup event={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}

function EventPopup({ event, onClose }) {
  const [calDropdown, setCalDropdown] = useState(false)
  const isLive = new Date(event.starts_at) <= new Date() && (!event.ends_at || new Date(event.ends_at) >= new Date())

  const calendarData = {
    title: event.title,
    description: event.description,
    location: event.address || event.venue_name,
    start: event.starts_at,
    end: event.ends_at,
  }

  return (
    <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl shadow-2xl p-4 animate-slide-up z-10">
      <button onClick={onClose} className="absolute top-3 right-3 w-7 h-7 bg-gray-100 rounded-full flex items-center justify-center">
        <X size={14} className="text-gray-500" />
      </button>

      <div className="flex items-center gap-2 mb-2">
        {isLive && (
          <span className="flex items-center gap-1 bg-[#C4622D] text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
            <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
            LIVE
          </span>
        )}
        <span className="text-xs text-gray-400">{event.brand?.name}</span>
      </div>

      <h3 className="font-bold text-base text-gray-900 mb-1 pr-8">{event.title}</h3>

      <div className="space-y-1 mb-3">
        <div className="flex items-center gap-1.5 text-gray-500">
          <Clock size={12} />
          <span className="text-xs">{formatDate(event.starts_at, 'EEE, d MMM · h:mm a')}</span>
        </div>
        <div className="flex items-center gap-1.5 text-gray-500">
          <MapPin size={12} />
          <span className="text-xs">{event.venue_name}</span>
        </div>
        {event.rsvp_count > 0 && (
          <div className="flex items-center gap-1.5 text-gray-500">
            <Users size={12} />
            <span className="text-xs">{event.rsvp_count} going</span>
          </div>
        )}
      </div>

      <div className="flex items-center gap-2">
        <button className="flex-1 bg-[#C4622D] hover:bg-[#a85225] text-white text-sm font-semibold py-2.5 rounded-xl transition-colors">
          RSVP
        </button>

        {/* Add to calendar */}
        <div className="relative">
          <button
            onClick={() => setCalDropdown(d => !d)}
            className="flex items-center gap-1.5 px-3 py-2.5 border-2 border-gray-200 rounded-xl text-sm font-semibold text-gray-600 hover:bg-gray-50 transition-colors"
          >
            <CalendarPlus size={16} />
          </button>
          {calDropdown && (
            <div className="absolute bottom-full right-0 mb-2 bg-white rounded-xl shadow-lg border border-gray-100 py-1 w-44 z-20">
              <a
                href={googleCalendarURL(calendarData)}
                target="_blank"
                rel="noopener noreferrer"
                className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                Google Calendar
              </a>
              <button
                onClick={() => { downloadICS(calendarData); setCalDropdown(false) }}
                className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                Download .ics file
              </button>
            </div>
          )}
        </div>

        {!event.is_free && (
          <span className="text-sm font-bold text-gray-900">{formatCurrency(event.ticket_price)}</span>
        )}
      </div>
    </div>
  )
}
