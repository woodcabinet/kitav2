import { Link } from 'react-router-dom'
import { Calendar, MapPin, Users, Clock } from 'lucide-react'
import { useState } from 'react'
import { cn, formatDate, formatCurrency } from '../../lib/utils'
import { Avatar } from '../shared/Avatar'

const EVENT_TYPE_LABELS = {
  market: '🏪 Market',
  pop_up: '⚡ Pop-Up',
  launch: '🚀 Launch',
  workshop: '🎨 Workshop',
  collab: '🤝 Collab',
  other: '📍 Event',
}

export function EventCard({ event, compact = false }) {
  const [rsvped, setRsvped] = useState(false)
  const isSoldOut = event.max_capacity && event.rsvp_count >= event.max_capacity

  if (compact) {
    return (
      <div className="flex gap-3 p-3 bg-white rounded-2xl border border-gray-100">
        <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
          {event.cover_url
            ? <img src={event.cover_url} alt="" className="w-full h-full object-cover" />
            : <div className="w-full h-full bg-[#F7F0E6] flex items-center justify-center text-2xl">
                {EVENT_TYPE_LABELS[event.event_type]?.slice(0, 2)}
              </div>
          }
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm text-gray-900 line-clamp-1">{event.title}</p>
          <p className="text-xs text-[#C4622D] font-medium">{EVENT_TYPE_LABELS[event.event_type]}</p>
          <div className="flex items-center gap-1 mt-0.5">
            <Calendar size={10} className="text-gray-400" />
            <span className="text-xs text-gray-500">{formatDate(event.starts_at, 'EEE, MMM d · h:mm a')}</span>
          </div>
          <div className="flex items-center gap-1">
            <MapPin size={10} className="text-gray-400" />
            <span className="text-xs text-gray-500 truncate">{event.venue_name}</span>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-3xl overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow">
      {/* Cover */}
      <div className="relative h-44 overflow-hidden">
        {event.cover_url
          ? <img src={event.cover_url} alt={event.title} className="w-full h-full object-cover" />
          : <div className="w-full h-full bg-gradient-to-br from-[#F7F0E6] to-[#E8DDD1] flex items-center justify-center text-5xl">
              {EVENT_TYPE_LABELS[event.event_type]?.slice(0, 2)}
            </div>
        }
        {/* Date badge */}
        <div className="absolute top-3 left-3 bg-white rounded-xl px-2.5 py-1.5 shadow-md">
          <p className="text-[10px] font-semibold text-[#C4622D] uppercase">{formatDate(event.starts_at, 'MMM')}</p>
          <p className="text-lg font-bold text-gray-900 leading-none">{formatDate(event.starts_at, 'd')}</p>
        </div>
        {/* Type badge */}
        <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm rounded-full px-2.5 py-1">
          <span className="text-white text-xs font-medium">{EVENT_TYPE_LABELS[event.event_type]}</span>
        </div>
        {/* Free/Price */}
        <div className="absolute bottom-3 right-3">
          {event.is_free
            ? <span className="bg-green-500 text-white text-xs font-bold px-2.5 py-1 rounded-full">FREE</span>
            : <span className="bg-white text-gray-900 text-xs font-bold px-2.5 py-1 rounded-full shadow">{formatCurrency(event.ticket_price)}</span>
          }
        </div>
      </div>

      <div className="p-4">
        {/* Brand */}
        <Link to={`/brand/${event.brand?.slug}`} className="flex items-center gap-2 mb-2">
          <Avatar src={event.brand?.logo_url} name={event.brand?.name} size="xs" />
          <span className="text-xs text-gray-500">{event.brand?.name}</span>
        </Link>

        <h3 className="font-bold text-base text-gray-900 mb-2 line-clamp-2">{event.title}</h3>

        <div className="space-y-1 mb-3">
          <div className="flex items-center gap-1.5 text-gray-500">
            <Clock size={13} />
            <span className="text-xs">{formatDate(event.starts_at, 'EEE, d MMM · h:mm a')}</span>
          </div>
          <div className="flex items-center gap-1.5 text-gray-500">
            <MapPin size={13} />
            <span className="text-xs truncate">{event.venue_name}, {event.address?.split(',').slice(-2).join(',').trim()}</span>
          </div>
          <div className="flex items-center gap-1.5 text-gray-500">
            <Users size={13} />
            <span className="text-xs">
              {event.rsvp_count} going
              {event.max_capacity && ` · ${event.max_capacity - event.rsvp_count} spots left`}
            </span>
          </div>
        </div>

        <button
          onClick={() => setRsvped(r => !r)}
          disabled={isSoldOut && !rsvped}
          className={cn(
            'w-full py-2.5 rounded-xl text-sm font-semibold transition-all',
            isSoldOut && !rsvped
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
              : rsvped
                ? 'bg-green-50 text-green-600 border border-green-200'
                : 'bg-[#C4622D] text-white hover:bg-[#a85225]'
          )}
        >
          {isSoldOut && !rsvped ? 'Sold Out' : rsvped ? '✓ Going' : 'RSVP Now'}
        </button>
      </div>
    </div>
  )
}
