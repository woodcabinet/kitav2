import { Link } from 'react-router-dom'
import { CheckCircle, MapPin } from 'lucide-react'
import { useState } from 'react'
import { cn, formatNumber } from '../../lib/utils'
import { CategoryBadge } from '../shared/Badge'
import { Avatar } from '../shared/Avatar'
import { Button } from '../shared/Button'

export function BrandCard({ brand, compact = false }) {
  const [followed, setFollowed] = useState(false)

  if (compact) {
    return (
      <Link to={`/brand/${brand.slug}`} className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-gray-100 hover:shadow-md transition-shadow">
        <Avatar src={brand.logo_url} name={brand.name} size="md" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1">
            <span className="font-semibold text-sm text-gray-900 truncate">{brand.name}</span>
            {brand.verified && <CheckCircle size={12} className="text-[#C4622D] flex-shrink-0" />}
          </div>
          <p className="text-xs text-gray-500 truncate">{brand.tagline}</p>
          <div className="flex items-center gap-1 mt-0.5">
            <MapPin size={10} className="text-gray-400" />
            <span className="text-xs text-gray-400">{brand.location}</span>
          </div>
        </div>
        <span className="text-xs text-gray-500 font-medium">{formatNumber(brand.follower_count)}</span>
      </Link>
    )
  }

  return (
    <div className="bg-white rounded-3xl overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow">
      {/* Banner */}
      <Link to={`/brand/${brand.slug}`}>
        <div className="h-28 bg-gradient-to-br from-[#F7F0E6] to-[#E8DDD1] overflow-hidden">
          {brand.banner_url && (
            <img src={brand.banner_url} alt="" className="w-full h-full object-cover" />
          )}
        </div>
      </Link>

      <div className="px-4 pb-4">
        {/* Avatar overlapping banner */}
        <div className="-mt-6 mb-2 flex items-end justify-between">
          <Link to={`/brand/${brand.slug}`}>
            <div className="ring-4 ring-white rounded-2xl overflow-hidden">
              <Avatar src={brand.logo_url} name={brand.name} size="lg" className="rounded-2xl" />
            </div>
          </Link>
          <button
            onClick={() => setFollowed(f => !f)}
            className={cn(
              'text-xs font-semibold px-4 py-1.5 rounded-xl border transition-all',
              followed
                ? 'border-gray-300 text-gray-500'
                : 'border-[#C4622D] text-[#C4622D] hover:bg-[#C4622D] hover:text-white'
            )}
          >
            {followed ? 'Following' : 'Follow'}
          </button>
        </div>

        <Link to={`/brand/${brand.slug}`}>
          <div className="flex items-center gap-1.5 mb-0.5">
            <h3 className="font-bold text-base text-gray-900">{brand.name}</h3>
            {brand.verified && <CheckCircle size={14} className="text-[#C4622D]" />}
          </div>
          <p className="text-sm text-gray-500 line-clamp-2 mb-2">{brand.tagline}</p>
        </Link>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1">
            <MapPin size={12} className="text-gray-400" />
            <span className="text-xs text-gray-400">{brand.location}</span>
          </div>
          <div className="flex items-center gap-2">
            <CategoryBadge category={brand.category} />
            <span className="text-xs text-gray-500">{formatNumber(brand.follower_count)} followers</span>
          </div>
        </div>
      </div>
    </div>
  )
}
