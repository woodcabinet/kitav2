import { useState } from 'react'
import { ShoppingBag, SlidersHorizontal } from 'lucide-react'
import { ProductCard } from '../../components/consumer/ProductCard'
import { MOCK_PRODUCTS } from '../../data/mockData'
import { CATEGORY_LABELS } from '../../lib/utils'

const CATEGORIES = ['all', 'fashion', 'accessories', 'coffee', 'home', 'stationery']

export default function ShopPage() {
  const [activeCategory, setActiveCategory] = useState('all')
  const [sortBy, setSortBy] = useState('newest')

  const filtered = MOCK_PRODUCTS.filter(p =>
    activeCategory === 'all' || p.category === activeCategory
  )

  return (
    <div className="pb-20">
      {/* Header */}
      <div className="px-4 pt-4 pb-3">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <ShoppingBag size={22} className="text-[#C4622D]" />
            <h1 className="text-2xl font-bold text-gray-900">Shop Local</h1>
          </div>
          <button className="w-9 h-9 bg-gray-100 rounded-xl flex items-center justify-center">
            <SlidersHorizontal size={16} className="text-gray-600" />
          </button>
        </div>
        <p className="text-sm text-gray-500">Payments go directly to the brands. Always.</p>
      </div>

      {/* Category pills */}
      <div className="flex gap-2 px-4 pb-3 overflow-x-auto scrollbar-hide">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`flex-shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium transition-all ${
              activeCategory === cat
                ? 'bg-[#C4622D] text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {cat === 'all' ? 'All' : CATEGORY_LABELS[cat] ?? cat.charAt(0).toUpperCase() + cat.slice(1)}
          </button>
        ))}
      </div>

      {/* Promise banner */}
      <div className="mx-4 mb-4 p-3 bg-green-50 rounded-2xl flex items-center gap-3 border border-green-100">
        <span className="text-2xl">🇸🇬</span>
        <div>
          <p className="font-semibold text-xs text-green-800">100% Local Brands</p>
          <p className="text-xs text-green-600">Payments go straight to the brand. We never hold your money.</p>
        </div>
      </div>

      {/* Products grid */}
      <div className="px-4 grid grid-cols-2 gap-3">
        {filtered.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <ShoppingBag size={40} className="text-gray-300 mx-auto mb-3" />
          <p className="font-bold text-gray-700">Nothing here yet</p>
          <p className="text-sm text-gray-400">This category is empty.</p>
        </div>
      )}
    </div>
  )
}
