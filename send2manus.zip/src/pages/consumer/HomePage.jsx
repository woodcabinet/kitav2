import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Zap, TrendingUp, MapPin } from 'lucide-react'
import { PostCard } from '../../components/consumer/PostCard'
import { BrandCard } from '../../components/consumer/BrandCard'
import { EventCard } from '../../components/consumer/EventCard'
import { MOCK_POSTS, MOCK_BRANDS, MOCK_EVENTS } from '../../data/mockData'

const FILTERS = ['All', 'Following', 'Fashion', 'Food & Drink', 'Lifestyle', 'Beauty']

export default function HomePage() {
  const [activeFilter, setActiveFilter] = useState('All')

  return (
    <div className="pb-20">
      {/* Stories / Brand Quick Access */}
      <div className="px-4 pt-4 pb-2">
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
          <Link to="/discover" className="flex flex-col items-center gap-1.5 flex-shrink-0">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#C4622D] to-[#a85225] flex items-center justify-center">
              <span className="text-white text-2xl">+</span>
            </div>
            <span className="text-[10px] text-gray-500 w-14 text-center truncate">Explore</span>
          </Link>
          {MOCK_BRANDS.map(brand => (
            <Link key={brand.id} to={`/brand/${brand.slug}`} className="flex flex-col items-center gap-1.5 flex-shrink-0">
              <div className="w-14 h-14 rounded-2xl overflow-hidden ring-2 ring-[#C4622D] ring-offset-2">
                <img src={brand.logo_url} alt={brand.name} className="w-full h-full object-cover" />
              </div>
              <span className="text-[10px] text-gray-500 w-14 text-center truncate">{brand.name}</span>
            </Link>
          ))}
        </div>
      </div>

      {/* Filter pills */}
      <div className="flex gap-2 px-4 pb-3 overflow-x-auto scrollbar-hide">
        {FILTERS.map(f => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            className={`flex-shrink-0 px-3.5 py-1.5 rounded-full text-sm font-medium transition-all ${
              activeFilter === f
                ? 'bg-[#C4622D] text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Upcoming drop teaser */}
      <div className="mx-4 mb-4 bg-gradient-to-r from-[#1A3A2A] to-[#2D5A40] rounded-2xl p-4 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 mb-1">
            <Zap size={14} className="text-[#C4622D]" />
            <span className="text-[#C4622D] text-xs font-bold uppercase tracking-wide">Next Drop</span>
          </div>
          <p className="text-white font-bold text-sm">Pandan Kaya Season Drop</p>
          <p className="text-white/60 text-xs">Sunday Folks · Tomorrow 10AM</p>
        </div>
        <Link to="/discover" className="bg-[#C4622D] text-white text-xs font-bold px-4 py-2 rounded-xl">
          Hype →
        </Link>
      </div>

      {/* Trending events quick bar */}
      <div className="px-4 mb-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <TrendingUp size={14} className="text-[#C4622D]" />
            <span className="text-sm font-bold text-gray-900">This Weekend</span>
          </div>
          <Link to="/discover" className="text-xs text-[#C4622D] font-semibold">See all</Link>
        </div>
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {MOCK_EVENTS.slice(0, 3).map(event => (
            <div key={event.id} className="flex-shrink-0 w-52">
              <EventCard event={event} compact />
            </div>
          ))}
        </div>
      </div>

      {/* Main feed */}
      <div className="space-y-1">
        {MOCK_POSTS.map(post => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>

      {/* Discover more prompt */}
      <div className="mx-4 mt-4 p-5 bg-[#F7F0E6] rounded-3xl text-center">
        <MapPin size={24} className="text-[#C4622D] mx-auto mb-2" />
        <p className="font-bold text-gray-900 mb-1">Discover more local brands</p>
        <p className="text-sm text-gray-500 mb-3">120+ Singapore brands and growing.</p>
        <Link to="/discover" className="inline-block bg-[#C4622D] text-white text-sm font-semibold px-6 py-2.5 rounded-xl">
          Explore Brands
        </Link>
      </div>
    </div>
  )
}
