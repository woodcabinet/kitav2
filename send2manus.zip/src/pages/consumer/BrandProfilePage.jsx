import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { CheckCircle, MapPin, Users, Grid3X3, ShoppingBag, Calendar, Share2 } from 'lucide-react'
import { MOCK_BRANDS, MOCK_POSTS, MOCK_EVENTS, MOCK_PRODUCTS } from '../../data/mockData'
import { PostCard } from '../../components/consumer/PostCard'
import { ProductCard } from '../../components/consumer/ProductCard'
import { EventCard } from '../../components/consumer/EventCard'
import { CategoryBadge } from '../../components/shared/Badge'
import { formatNumber } from '../../lib/utils'
import { cn } from '../../lib/utils'

export default function BrandProfilePage() {
  const { slug } = useParams()
  const brand = MOCK_BRANDS.find(b => b.slug === slug) ?? MOCK_BRANDS[0]
  const [activeTab, setActiveTab] = useState('posts')
  const [followed, setFollowed] = useState(false)

  const brandPosts = MOCK_POSTS.filter(p => p.brand_id === brand.id)
  const brandProducts = MOCK_PRODUCTS.filter(p => p.brand_id === brand.id)
  const brandEvents = MOCK_EVENTS.filter(e => e.brand_id === brand.id)

  const TABS = [
    { id: 'posts', label: 'Posts', icon: Grid3X3, count: brandPosts.length },
    { id: 'shop', label: 'Shop', icon: ShoppingBag, count: brandProducts.length },
    { id: 'events', label: 'Events', icon: Calendar, count: brandEvents.length },
  ]

  return (
    <div className="pb-20">
      {/* Banner */}
      <div className="relative h-40 bg-gradient-to-br from-[#F7F0E6] to-[#E8DDD1]">
        {brand.banner_url && <img src={brand.banner_url} alt="" className="w-full h-full object-cover" />}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
        <button className="absolute top-4 right-4 w-9 h-9 bg-white/80 backdrop-blur rounded-xl flex items-center justify-center text-gray-600">
          <Share2 size={16} />
        </button>
      </div>

      {/* Profile info */}
      <div className="px-4 -mt-10 mb-4">
        <div className="flex items-end justify-between mb-3">
          <div className="ring-4 ring-white rounded-2xl overflow-hidden shadow-md">
            <img src={brand.logo_url} alt={brand.name} className="w-20 h-20 object-cover" />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setFollowed(f => !f)}
              className={`px-5 py-2 rounded-xl text-sm font-semibold border-2 transition-all ${
                followed
                  ? 'border-gray-300 text-gray-500'
                  : 'border-[#C4622D] text-[#C4622D] hover:bg-[#C4622D] hover:text-white'
              }`}
            >
              {followed ? 'Following' : 'Follow'}
            </button>
            <button className="px-4 py-2 rounded-xl text-sm font-semibold bg-gray-100 text-gray-600 hover:bg-gray-200 transition-all">
              Message
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-1">
          <h1 className="text-xl font-bold text-gray-900">{brand.name}</h1>
          {brand.verified && <CheckCircle size={16} className="text-[#C4622D]" />}
        </div>
        <p className="text-sm text-gray-500 mb-2">{brand.tagline}</p>
        <div className="flex items-center gap-1.5 mb-3">
          <MapPin size={13} className="text-gray-400" />
          <span className="text-sm text-gray-400">{brand.location}</span>
          <span className="text-gray-300">·</span>
          <CategoryBadge category={brand.category} />
        </div>

        {/* Stats */}
        <div className="flex gap-6">
          <div className="text-center">
            <p className="font-bold text-gray-900">{formatNumber(brand.follower_count)}</p>
            <p className="text-xs text-gray-400">Followers</p>
          </div>
          <div className="text-center">
            <p className="font-bold text-gray-900">{brandPosts.length}</p>
            <p className="text-xs text-gray-400">Posts</p>
          </div>
          <div className="text-center">
            <p className="font-bold text-gray-900">{brandProducts.length}</p>
            <p className="text-xs text-gray-400">Products</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-100 px-4 mb-4">
        {TABS.map(({ id, label, icon: Icon, count }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-1.5 px-4 py-3 text-sm font-semibold border-b-2 transition-all ${
              activeTab === id
                ? 'border-[#C4622D] text-[#C4622D]'
                : 'border-transparent text-gray-400'
            }`}
          >
            <Icon size={14} />
            {label}
            {count > 0 && <span className="text-[10px]">({count})</span>}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="px-4">
        {activeTab === 'posts' && (
          <div className="space-y-4">
            {brandPosts.length > 0
              ? brandPosts.map(post => <PostCard key={post.id} post={post} />)
              : <p className="text-center text-gray-400 py-8">No posts yet.</p>
            }
          </div>
        )}
        {activeTab === 'shop' && (
          <div className="grid grid-cols-2 gap-3">
            {brandProducts.length > 0
              ? brandProducts.map(p => <ProductCard key={p.id} product={p} />)
              : <p className="col-span-2 text-center text-gray-400 py-8">No products yet.</p>
            }
          </div>
        )}
        {activeTab === 'events' && (
          <div className="space-y-4">
            {brandEvents.length > 0
              ? brandEvents.map(e => <EventCard key={e.id} event={e} />)
              : <p className="text-center text-gray-400 py-8">No upcoming events.</p>
            }
          </div>
        )}
      </div>
    </div>
  )
}
