import { Gift, Star, Zap, CheckCircle, Lock } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'

const TIERS = [
  { name: 'Kawan', min: 0, max: 499, color: 'bg-gray-200 text-gray-600', icon: '🤝' },
  { name: 'Sayang', min: 500, max: 1999, color: 'bg-[#C4622D]/20 text-[#C4622D]', icon: '❤️' },
  { name: 'Jaguh', min: 2000, max: 4999, color: 'bg-yellow-100 text-yellow-700', icon: '⭐' },
  { name: 'Pahlawan', min: 5000, max: Infinity, color: 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white', icon: '🏆' },
]

const HOW_TO_EARN = [
  { action: 'Follow a local brand', points: '+5', icon: '👥' },
  { action: 'Attend an event', points: '+50', icon: '📍' },
  { action: 'Make a purchase', points: '+100 per $10', icon: '🛍️' },
  { action: 'Share a post', points: '+10', icon: '📤' },
  { action: 'Refer a friend', points: '+200', icon: '🎯' },
  { action: 'Daily check-in', points: '+2', icon: '📅' },
  { action: 'Write a review', points: '+25', icon: '✏️' },
]

const REWARDS = [
  { title: '$5 off Assembly Coffee', brand: 'Assembly Coffee', points: 200, available: true },
  { title: 'Free tote with any purchase', brand: 'Supermama', points: 350, available: true },
  { title: 'Workshop slot discount 20%', brand: 'Bynd Artisan', points: 500, available: true },
  { title: 'Free soft serve', brand: 'Sunday Folks', points: 150, available: false },
]

export default function RewardsPage() {
  const { profile } = useAuth()
  const points = profile?.points ?? 240 // demo
  const tier = TIERS.find(t => points >= t.min && points <= t.max) ?? TIERS[0]
  const nextTier = TIERS[TIERS.indexOf(tier) + 1]
  const progress = nextTier ? ((points - tier.min) / (nextTier.min - tier.min)) * 100 : 100

  return (
    <div className="pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#1A3A2A] to-[#2D5A40] px-4 pt-6 pb-8">
        <div className="flex items-center gap-2 mb-4">
          <Gift size={22} className="text-[#C4622D]" />
          <h1 className="text-xl font-bold text-white">Rewards</h1>
        </div>

        {/* Points card */}
        <div className="bg-white/10 backdrop-blur rounded-3xl p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-white/60 text-xs mb-1">Your Points</p>
              <p className="text-4xl font-bold text-white">{points.toLocaleString()}</p>
              <p className="text-white/60 text-xs mt-1">≈ ${(points / 100).toFixed(2)} in rewards</p>
            </div>
            <div className={`${tier.color} rounded-2xl px-3 py-1.5 flex items-center gap-1.5`}>
              <span>{tier.icon}</span>
              <span className="font-bold text-sm">{tier.name}</span>
            </div>
          </div>

          {/* Progress to next tier */}
          {nextTier && (
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-white/60">{points} pts</span>
                <span className="text-white/60">{nextTier.min} pts to {nextTier.name}</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#C4622D] rounded-full transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-white/60 text-xs mt-1.5">{nextTier.min - points} more points to {nextTier.name} {nextTier.icon}</p>
            </div>
          )}
        </div>
      </div>

      <div className="px-4 -mt-4 space-y-4">
        {/* Redeem rewards */}
        <div className="bg-white rounded-3xl p-4 border border-gray-100">
          <h2 className="font-bold text-gray-900 mb-3">Redeem Rewards</h2>
          <div className="space-y-2">
            {REWARDS.map(reward => {
              const canRedeem = points >= reward.points
              return (
                <div key={reward.title} className={`flex items-center justify-between p-3 rounded-2xl border ${
                  reward.available ? 'border-gray-100' : 'border-gray-100 opacity-50'
                }`}>
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-gray-900">{reward.title}</p>
                    <p className="text-xs text-gray-400">{reward.brand}</p>
                    <div className="flex items-center gap-1 mt-0.5">
                      <Star size={10} className="text-[#C4622D]" />
                      <span className="text-xs font-semibold text-[#C4622D]">{reward.points} pts</span>
                    </div>
                  </div>
                  <button
                    disabled={!canRedeem || !reward.available}
                    className={`ml-3 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      canRedeem && reward.available
                        ? 'bg-[#C4622D] text-white hover:bg-[#a85225]'
                        : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    {!reward.available ? 'Unavailable' : canRedeem ? 'Redeem' : <Lock size={12} />}
                  </button>
                </div>
              )
            })}
          </div>
        </div>

        {/* How to earn */}
        <div className="bg-white rounded-3xl p-4 border border-gray-100">
          <h2 className="font-bold text-gray-900 mb-3">How to Earn</h2>
          <div className="space-y-2">
            {HOW_TO_EARN.map(item => (
              <div key={item.action} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-2.5">
                  <span className="text-lg">{item.icon}</span>
                  <span className="text-sm text-gray-700">{item.action}</span>
                </div>
                <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">{item.points}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Tiers */}
        <div className="bg-white rounded-3xl p-4 border border-gray-100 mb-4">
          <h2 className="font-bold text-gray-900 mb-3">Member Tiers</h2>
          <div className="space-y-2">
            {TIERS.map(t => (
              <div key={t.name} className={`flex items-center gap-3 p-3 rounded-2xl ${tier.name === t.name ? 'bg-[#F7F0E6]' : ''}`}>
                <span className="text-xl">{t.icon}</span>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-gray-900">{t.name}</span>
                    {tier.name === t.name && <CheckCircle size={12} className="text-[#C4622D]" />}
                  </div>
                  <p className="text-xs text-gray-400">
                    {t.max === Infinity ? `${t.min.toLocaleString()}+ pts` : `${t.min.toLocaleString()} – ${t.max.toLocaleString()} pts`}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
