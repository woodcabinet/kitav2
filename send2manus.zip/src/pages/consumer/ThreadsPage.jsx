import { useState } from 'react'
import { MessageSquare, Heart, Reply, TrendingUp, Plus } from 'lucide-react'
import { Avatar } from '../../components/shared/Avatar'
import { MOCK_THREADS } from '../../data/mockData'
import { formatRelativeTime, formatNumber } from '../../lib/utils'

function ThreadCard({ thread }) {
  const [liked, setLiked] = useState(false)
  const [likes, setLikes] = useState(thread.like_count)

  function handleLike() {
    setLiked(l => !l)
    setLikes(c => liked ? c - 1 : c + 1)
  }

  return (
    <div className="bg-white border-b border-gray-100 px-4 py-4">
      <div className="flex gap-3">
        <Avatar src={thread.author?.avatar_url} name={thread.author?.display_name} size="sm" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold text-sm text-gray-900">{thread.author?.display_name}</span>
            <span className="text-gray-400">·</span>
            <span className="text-xs text-gray-400">{formatRelativeTime(thread.created_at)}</span>
          </div>
          <p className="text-sm text-gray-800 leading-relaxed mb-2">{thread.content}</p>
          {thread.tags?.length > 0 && (
            <div className="flex gap-1.5 flex-wrap mb-3">
              {thread.tags.map(tag => (
                <span key={tag} className="text-xs text-[#C4622D] font-medium">#{tag}</span>
              ))}
            </div>
          )}
          <div className="flex items-center gap-4">
            <button onClick={handleLike} className={`flex items-center gap-1.5 text-sm transition-colors ${liked ? 'text-red-500' : 'text-gray-400 hover:text-gray-600'}`}>
              <Heart size={16} className={liked ? 'fill-current' : ''} />
              <span>{formatNumber(likes)}</span>
            </button>
            <button className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-600">
              <Reply size={16} />
              <span>{formatNumber(thread.reply_count)}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function ThreadsPage() {
  const [activeTab, setActiveTab] = useState('trending')

  return (
    <div className="pb-20">
      {/* Header */}
      <div className="px-4 pt-4 pb-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Threads</h1>
            <p className="text-sm text-gray-500">The local community is talking.</p>
          </div>
          <button className="w-10 h-10 bg-[#C4622D] rounded-xl flex items-center justify-center">
            <Plus size={20} className="text-white" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-100 mb-2 px-4">
        {[
          { id: 'trending', label: 'Trending', icon: TrendingUp },
          { id: 'recent', label: 'Recent', icon: MessageSquare },
        ].map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-1.5 px-4 py-3 text-sm font-semibold border-b-2 transition-colors ${
              activeTab === id
                ? 'border-[#C4622D] text-[#C4622D]'
                : 'border-transparent text-gray-400 hover:text-gray-600'
            }`}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </div>

      {/* Thread list */}
      <div>
        {MOCK_THREADS.map(thread => (
          <ThreadCard key={thread.id} thread={thread} />
        ))}
      </div>
    </div>
  )
}
