import { useState } from 'react'
import {
  Sparkles, CheckCircle, ArrowRight, Instagram, Globe, Search, Zap,
  BarChart2, RefreshCw, AlertCircle, Package
} from 'lucide-react'
import { scrapeBrand } from '../../lib/brandScraper'
import { CATEGORY_LABELS } from '../../lib/utils'

const STEPS = [
  { id: 'claim', label: 'Find brand', icon: Search },
  { id: 'scan', label: 'AI scan', icon: Sparkles },
  { id: 'review', label: 'Review', icon: CheckCircle },
  { id: 'live', label: 'Go live', icon: Zap },
]

const SCAN_STAGES = [
  'Fetching your website...',
  'Detecting e-commerce platform...',
  'Importing product catalogue...',
  'Extracting imagery and branding...',
  'Scanning Instagram profile...',
  'Generating suggestions...',
]

export default function OnboardingPage() {
  const [step, setStep] = useState(0)
  const [website, setWebsite] = useState('')
  const [handle, setHandle] = useState('')
  const [scanning, setScanning] = useState(false)
  const [stageIdx, setStageIdx] = useState(0)
  const [scraped, setScraped] = useState(null)
  const [error, setError] = useState(null)

  async function runScan() {
    if (!website && !handle) {
      setError('Enter at least a website or Instagram handle.')
      return
    }
    setError(null)
    setScanning(true)
    setStep(1)
    const stageTimer = setInterval(() => {
      setStageIdx(i => Math.min(i + 1, SCAN_STAGES.length - 1))
    }, 900)
    try {
      const data = await scrapeBrand({ website: website || undefined, instagram: handle || undefined })
      clearInterval(stageTimer)
      setScraped(data)
      setStep(2)
    } catch (e) {
      clearInterval(stageTimer)
      setError(e.message ?? 'Scan failed. Try a different URL.')
      setStep(0)
    } finally {
      setScanning(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#F7F0E6] flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-2">
            <div className="w-10 h-10 rounded-2xl bg-[#C4622D] flex items-center justify-center">
              <span className="text-white font-bold text-lg">K</span>
            </div>
            <span className="font-bold text-2xl text-[#1A3A2A]">kitakakis</span>
          </div>
          <p className="text-gray-500 text-sm">Zero-friction onboarding — we'll pull everything from what's already online.</p>
        </div>

        {/* Progress */}
        <div className="flex items-center justify-between mb-8 px-2">
          {STEPS.map((s, i) => {
            const Icon = s.icon
            const done = i < step
            const active = i === step
            return (
              <div key={s.id} className="flex items-center flex-1 last:flex-none">
                <div className={`flex flex-col items-center gap-1 ${active || done ? 'opacity-100' : 'opacity-40'}`}>
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${
                    done ? 'bg-green-500' : active ? 'bg-[#C4622D]' : 'bg-gray-200'
                  }`}>
                    {done ? <CheckCircle size={18} className="text-white" /> : <Icon size={18} className={active ? 'text-white' : 'text-gray-500'} />}
                  </div>
                  <span className="text-[10px] font-medium text-gray-600 text-center w-16">{s.label}</span>
                </div>
                {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 mx-2 mb-4 ${done ? 'bg-green-500' : 'bg-gray-200'}`} />}
              </div>
            )
          })}
        </div>

        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
          {/* STEP 0 — claim */}
          {step === 0 && (
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-[#F7F0E6] rounded-2xl flex items-center justify-center">
                  <Search size={22} className="text-[#C4622D]" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Point us at what's already live.</h2>
                  <p className="text-sm text-gray-500">Our AI will scan your site and socials, import your products, and build your profile in under a minute.</p>
                </div>
              </div>

              <div className="bg-[#F7F0E6] rounded-2xl p-4 mb-6">
                <p className="text-sm font-semibold text-[#1A3A2A] mb-1">What we auto-import</p>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>✓ Brand name, tagline, description (from your website meta)</li>
                  <li>✓ Logo and hero imagery (og:image + content scan)</li>
                  <li>✓ Full product catalogue with prices and photos (Shopify auto-detected)</li>
                  <li>✓ Instagram follower count and profile picture</li>
                  <li>✓ Suggested category + hashtags</li>
                </ul>
              </div>

              <div className="space-y-3 mb-6">
                <div>
                  <label className="text-sm font-semibold text-gray-700 mb-1.5 block flex items-center gap-1.5">
                    <Globe size={14} /> Website URL
                  </label>
                  <input
                    type="url"
                    value={website}
                    onChange={e => setWebsite(e.target.value)}
                    placeholder="vintagewknd.com"
                    className="w-full px-3 py-3 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-[#C4622D]/30"
                  />
                </div>
                <div>
                  <label className="text-sm font-semibold text-gray-700 mb-1.5 block flex items-center gap-1.5">
                    <Instagram size={14} /> Instagram Handle <span className="text-gray-400 font-normal">(optional)</span>
                  </label>
                  <div className="flex items-center border border-gray-200 rounded-xl overflow-hidden">
                    <span className="px-3 py-3 bg-gray-50 text-gray-400 text-sm border-r border-gray-200">@</span>
                    <input
                      type="text"
                      value={handle}
                      onChange={e => setHandle(e.target.value)}
                      placeholder="vintagewknd"
                      className="flex-1 px-3 py-3 text-sm outline-none"
                    />
                  </div>
                </div>
              </div>

              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-100 rounded-xl flex items-start gap-2">
                  <AlertCircle size={16} className="text-red-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-600">{error}</p>
                </div>
              )}

              <button onClick={runScan} className="w-full bg-[#C4622D] hover:bg-[#a85225] text-white font-semibold py-3.5 rounded-xl flex items-center justify-center gap-2 transition-colors">
                <Sparkles size={18} /> Auto-fill My Brand
              </button>
              <p className="text-xs text-gray-400 text-center mt-3">Try: vintagewknd.com · toneffclothing.com · heritagebayshop.com</p>
            </div>
          )}

          {/* STEP 1 — scanning */}
          {step === 1 && (
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-[#F7F0E6] rounded-2xl flex items-center justify-center">
                  <RefreshCw size={22} className="text-[#C4622D] animate-spin" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Scanning your public profiles...</h2>
                  <p className="text-sm text-gray-500">No logins needed. We only read what's already public.</p>
                </div>
              </div>
              <div className="space-y-2 py-4">
                {SCAN_STAGES.map((msg, i) => (
                  <div key={msg} className={`flex items-center gap-2 text-sm transition-all ${
                    i < stageIdx ? 'text-gray-400' : i === stageIdx ? 'text-gray-900 font-semibold' : 'text-gray-300'
                  }`}>
                    {i < stageIdx ? <CheckCircle size={14} className="text-green-500" /> :
                      i === stageIdx ? <RefreshCw size={14} className="text-[#C4622D] animate-spin" /> :
                      <div className="w-3.5 h-3.5 rounded-full border border-gray-300" />}
                    {msg}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2 — review */}
          {step === 2 && scraped && (
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                  <CheckCircle size={22} className="text-green-600" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Found your brand.</h2>
                  <p className="text-sm text-gray-500">Review, edit if needed, confirm to go live.</p>
                </div>
              </div>

              {/* Hero preview */}
              <div className="relative rounded-2xl overflow-hidden border border-gray-100 mb-4">
                {scraped.banner_url && (
                  <img src={scraped.banner_url} alt="" className="w-full h-32 object-cover" referrerPolicy="no-referrer" />
                )}
                <div className="p-4 flex items-center gap-3">
                  {scraped.logo_url && (
                    <img src={scraped.logo_url} alt="" className="w-14 h-14 rounded-2xl object-cover border border-gray-100" referrerPolicy="no-referrer" />
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-gray-900 truncate">{scraped.name ?? 'Untitled brand'}</p>
                    <p className="text-sm text-gray-500 line-clamp-2">{scraped.tagline}</p>
                  </div>
                  <span className="text-xs bg-green-50 text-green-600 font-semibold px-2 py-1 rounded-lg">
                    {scraped.platform ?? 'web'}
                  </span>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="bg-[#F7F0E6] rounded-2xl p-3 text-center">
                  <p className="font-bold text-[#C4622D] text-lg">{scraped.products?.length ?? 0}</p>
                  <p className="text-[10px] text-gray-500 uppercase tracking-wide">Products imported</p>
                </div>
                <div className="bg-[#F7F0E6] rounded-2xl p-3 text-center">
                  <p className="font-bold text-[#C4622D] text-lg">{scraped.gallery?.length ?? 0}</p>
                  <p className="text-[10px] text-gray-500 uppercase tracking-wide">Images extracted</p>
                </div>
                <div className="bg-[#F7F0E6] rounded-2xl p-3 text-center">
                  <p className="font-bold text-[#C4622D] text-lg">{scraped.instagram?.followers ?? '—'}</p>
                  <p className="text-[10px] text-gray-500 uppercase tracking-wide">IG followers</p>
                </div>
              </div>

              {/* Product preview */}
              {scraped.products?.length > 0 && (
                <div className="mb-4">
                  <div className="flex items-center gap-1.5 mb-2">
                    <Package size={14} className="text-[#C4622D]" />
                    <p className="text-sm font-semibold text-gray-700">Products ready to sell</p>
                  </div>
                  <div className="grid grid-cols-4 gap-2">
                    {scraped.products.slice(0, 4).map(p => (
                      <div key={p.id} className="rounded-xl overflow-hidden border border-gray-100">
                        {p.images[0] && <img src={p.images[0]} alt={p.name} className="w-full aspect-square object-cover" referrerPolicy="no-referrer" />}
                        <div className="p-1.5">
                          <p className="text-[10px] font-semibold text-gray-900 truncate">{p.name}</p>
                          <p className="text-[10px] text-gray-500">${p.price}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Category + tags */}
              <div className="mb-4 p-3 bg-white border border-gray-100 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">Suggested category</span>
                  <span className="text-sm font-semibold text-gray-900">{CATEGORY_LABELS?.[scraped.suggested_category] ?? scraped.suggested_category}</span>
                </div>
                <div className="flex flex-wrap gap-1 pt-2 border-t border-gray-50">
                  {scraped.suggested_tags?.map(t => (
                    <span key={t} className="text-[10px] bg-[#F7F0E6] text-[#C4622D] px-2 py-0.5 rounded-full">{t}</span>
                  ))}
                </div>
              </div>

              {scraped.warnings?.length > 0 && (
                <div className="mb-4 p-3 bg-yellow-50 border border-yellow-100 rounded-xl">
                  {scraped.warnings.map(w => (
                    <p key={w} className="text-xs text-yellow-700 flex items-start gap-1.5"><AlertCircle size={12} className="mt-0.5 flex-shrink-0" />{w}</p>
                  ))}
                </div>
              )}

              <button onClick={() => setStep(3)} className="w-full bg-[#C4622D] hover:bg-[#a85225] text-white font-semibold py-3.5 rounded-xl flex items-center justify-center gap-2">
                Confirm & Go Live <ArrowRight size={18} />
              </button>
            </div>
          )}

          {/* STEP 3 — live */}
          {step === 3 && (
            <div className="text-center py-4">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap size={36} className="text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">You're live 🎉</h2>
              <p className="text-gray-500 mb-6">
                {scraped?.name ?? 'Your brand'} is now on Kitakakis. Products synced, content ready, dashboard waiting.
              </p>
              <div className="grid grid-cols-3 gap-3 mb-8 text-center">
                <div className="bg-[#F7F0E6] rounded-2xl p-3">
                  <p className="font-bold text-[#C4622D] text-xl">{scraped?.products?.length ?? 0}</p>
                  <p className="text-xs text-gray-500">Products synced</p>
                </div>
                <div className="bg-[#F7F0E6] rounded-2xl p-3">
                  <p className="font-bold text-[#C4622D] text-xl">{scraped?.gallery?.length ?? 0}</p>
                  <p className="text-xs text-gray-500">Images imported</p>
                </div>
                <div className="bg-[#F7F0E6] rounded-2xl p-3">
                  <p className="font-bold text-[#C4622D] text-xl">✓</p>
                  <p className="text-xs text-gray-500">Dashboard ready</p>
                </div>
              </div>
              <a href="/dashboard" className="block w-full bg-[#1A3A2A] text-white font-semibold py-3.5 rounded-xl hover:bg-[#0f2319]">
                Go to Dashboard →
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
