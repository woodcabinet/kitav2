import { useState } from 'react'
import { Package, Plus, Zap, Edit2, Trash2, Eye, EyeOff, Search, MoreHorizontal, DollarSign, ShoppingBag, BarChart2, Clock, Flame } from 'lucide-react'
import { MOCK_PRODUCTS, MOCK_DROPS } from '../../data/mockData'
import { formatCurrency, formatDate, formatCountdown, formatNumber } from '../../lib/utils'

const TABS = [
  { id: 'products', label: 'Products', icon: Package },
  { id: 'drops', label: 'Drops', icon: Zap },
  { id: 'orders', label: 'Orders', icon: ShoppingBag },
]

// ─── Mock orders ──────────────────────────────────────────
const MOCK_ORDERS = [
  { id: 'o1', customer: 'Marcus T.', items: [{ name: 'Ethiopia Yirgacheffe 250g', qty: 2 }], total: 56, status: 'confirmed', date: new Date(Date.now() - 2 * 3600000).toISOString() },
  { id: 'o2', customer: 'Priya N.', items: [{ name: 'Ethiopia Yirgacheffe 250g', qty: 1 }], total: 28, status: 'shipped', date: new Date(Date.now() - 24 * 3600000).toISOString() },
  { id: 'o3', customer: 'Jun W.', items: [{ name: 'Ethiopia Yirgacheffe 250g', qty: 3 }], total: 84, status: 'delivered', date: new Date(Date.now() - 72 * 3600000).toISOString() },
]

const STATUS_STYLES = {
  pending: 'bg-yellow-50 text-yellow-700',
  confirmed: 'bg-blue-50 text-blue-700',
  shipped: 'bg-purple-50 text-purple-700',
  delivered: 'bg-green-50 text-green-700',
  cancelled: 'bg-red-50 text-red-700',
}

// ─── Products Tab ──────────────────────────────────────────

function ProductsTab() {
  const [query, setQuery] = useState('')
  const products = MOCK_PRODUCTS.filter(p =>
    !query || p.name.toLowerCase().includes(query.toLowerCase())
  )

  return (
    <div>
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: 'Total Products', value: MOCK_PRODUCTS.length, icon: Package, color: 'bg-[#F7F0E6]' },
          { label: 'In Stock', value: MOCK_PRODUCTS.filter(p => p.stock > 0).length, icon: Eye, color: 'bg-green-50' },
          { label: 'Revenue (MTD)', value: '$12,840', icon: DollarSign, color: 'bg-[#F7F0E6]' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-white rounded-2xl border border-gray-100 p-4">
            <div className="flex items-center justify-between mb-2">
              <div className={`w-8 h-8 ${color} rounded-xl flex items-center justify-center`}>
                <Icon size={16} className="text-[#C4622D]" />
              </div>
            </div>
            <p className="text-xl font-bold text-gray-900">{value}</p>
            <p className="text-xs text-gray-500">{label}</p>
          </div>
        ))}
      </div>

      {/* Search + Add */}
      <div className="flex gap-2 mb-4">
        <div className="flex-1 relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search products..."
            className="w-full pl-9 pr-3 py-2 bg-white border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-[#C4622D]/30"
          />
        </div>
        <button className="flex items-center gap-2 bg-[#C4622D] hover:bg-[#a85225] text-white text-sm font-semibold px-4 py-2 rounded-xl transition-colors">
          <Plus size={16} /> Add Product
        </button>
      </div>

      {/* Product table */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-100 text-xs text-gray-500 uppercase tracking-wide">
              <th className="text-left px-4 py-3 font-semibold">Product</th>
              <th className="text-left px-4 py-3 font-semibold">Price</th>
              <th className="text-left px-4 py-3 font-semibold">Stock</th>
              <th className="text-left px-4 py-3 font-semibold">Status</th>
              <th className="text-right px-4 py-3 font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map(product => {
              const isOutOfStock = product.stock === 0 && !product.unlimited_stock
              const isDrop = !!product.drop_at
              return (
                <tr key={product.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                        {product.images?.[0] && <img src={product.images[0]} alt="" className="w-full h-full object-cover" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <p className="font-semibold text-sm text-gray-900">{product.name}</p>
                          {isDrop && (
                            <span className="flex items-center gap-0.5 bg-[#C4622D] text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">
                              <Zap size={8} /> DROP
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-400">{product.category}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-sm text-gray-900">{formatCurrency(product.price)}</span>
                      {product.compare_price && (
                        <span className="text-xs text-gray-400 line-through">{formatCurrency(product.compare_price)}</span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-medium ${isOutOfStock ? 'text-red-500' : product.stock < 10 ? 'text-orange-500' : 'text-gray-700'}`}>
                      {isOutOfStock ? 'Out of stock' : `${product.stock} units`}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {isDrop ? (
                      <span className="text-xs font-semibold text-[#C4622D] bg-[#F7F0E6] px-2 py-1 rounded-lg">
                        Drop: {formatDate(product.drop_at, 'MMM d, h:mm a')}
                      </span>
                    ) : isOutOfStock ? (
                      <span className="text-xs font-semibold text-red-600 bg-red-50 px-2 py-1 rounded-lg">Sold Out</span>
                    ) : (
                      <span className="text-xs font-semibold text-green-600 bg-green-50 px-2 py-1 rounded-lg">Active</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button className="w-7 h-7 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600">
                        <Edit2 size={14} />
                      </button>
                      <button className="w-7 h-7 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600">
                        <BarChart2 size={14} />
                      </button>
                      <button className="w-7 h-7 rounded-lg hover:bg-red-50 flex items-center justify-center text-gray-400 hover:text-red-500">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── Drops Tab (create + manage drops) ─────────────────────

function DropsTab() {
  const [showCreate, setShowCreate] = useState(false)

  return (
    <div>
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: 'Total Drops', value: MOCK_DROPS.length, icon: Zap },
          { label: 'Total Hype', value: formatNumber(MOCK_DROPS.reduce((s, d) => s + d.hype_count, 0)), icon: Flame },
          { label: 'Next Drop', value: 'In 3 days', icon: Clock },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="bg-white rounded-2xl border border-gray-100 p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 bg-[#F7F0E6] rounded-xl flex items-center justify-center">
                <Icon size={16} className="text-[#C4622D]" />
              </div>
            </div>
            <p className="text-xl font-bold text-gray-900">{value}</p>
            <p className="text-xs text-gray-500">{label}</p>
          </div>
        ))}
      </div>

      {/* Create drop */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-gray-900">Drop Schedule</h3>
        <button
          onClick={() => setShowCreate(s => !s)}
          className="flex items-center gap-2 bg-[#C4622D] hover:bg-[#a85225] text-white text-sm font-semibold px-4 py-2 rounded-xl transition-colors"
        >
          <Zap size={16} /> Create Drop
        </button>
      </div>

      {showCreate && (
        <div className="bg-white rounded-2xl border border-gray-100 p-5 mb-4">
          <h4 className="font-bold text-gray-900 mb-4">New Drop</h4>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Drop Name</label>
              <input type="text" placeholder="e.g. Summer Capsule Drop" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-[#C4622D]/30" />
            </div>
            <div>
              <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Drop Date & Time</label>
              <input type="datetime-local" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-[#C4622D]/30" />
            </div>
          </div>
          <div className="mb-4">
            <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Description</label>
            <textarea rows={3} placeholder="Describe the drop — build hype..." className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm outline-none resize-none focus:ring-2 focus:ring-[#C4622D]/30" />
          </div>
          <div className="mb-4">
            <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Cover Image</label>
            <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center hover:border-[#C4622D] transition-colors cursor-pointer">
              <p className="text-2xl mb-1">📸</p>
              <p className="text-sm text-gray-500">Drop + drag or click to upload</p>
            </div>
          </div>
          <div className="mb-4">
            <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Products in this Drop</label>
            <p className="text-xs text-gray-400 mb-2">Select existing products or add new ones to include in the drop.</p>
            <div className="space-y-2">
              {MOCK_PRODUCTS.slice(0, 3).map(p => (
                <label key={p.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100 transition-colors">
                  <input type="checkbox" className="w-4 h-4 accent-[#C4622D] rounded" />
                  <div className="w-8 h-8 rounded-lg overflow-hidden flex-shrink-0">
                    {p.images?.[0] && <img src={p.images[0]} alt="" className="w-full h-full object-cover" />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{p.name}</p>
                    <p className="text-xs text-gray-400">{formatCurrency(p.price)} · {p.stock} in stock</p>
                  </div>
                </label>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <button className="flex-1 bg-[#C4622D] hover:bg-[#a85225] text-white font-semibold py-2.5 rounded-xl transition-colors">
              Schedule Drop
            </button>
            <button onClick={() => setShowCreate(false)} className="px-4 py-2.5 border border-gray-200 rounded-xl text-gray-600 font-semibold hover:bg-gray-50">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Drop list */}
      <div className="space-y-3">
        {MOCK_DROPS.map(drop => {
          const countdown = formatCountdown(drop.drop_at)
          const isPast = new Date(drop.drop_at) < new Date()
          return (
            <div key={drop.id} className="bg-white rounded-2xl border border-gray-100 p-4 flex gap-4 hover:shadow-sm transition-shadow">
              <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
                {drop.cover_url && <img src={drop.cover_url} alt="" className="w-full h-full object-cover" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-bold text-sm text-gray-900 truncate">{drop.title}</h4>
                  {isPast ? (
                    <span className="text-[10px] font-semibold bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">Completed</span>
                  ) : countdown.live ? (
                    <span className="flex items-center gap-1 text-[10px] font-bold bg-[#C4622D] text-white px-2 py-0.5 rounded-full">
                      <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> LIVE
                    </span>
                  ) : (
                    <span className="text-[10px] font-semibold bg-[#F7F0E6] text-[#C4622D] px-2 py-0.5 rounded-full">
                      In {countdown.days}d {countdown.hours}h
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500 line-clamp-1 mb-1.5">{drop.description}</p>
                <div className="flex items-center gap-4 text-xs text-gray-400">
                  <span className="flex items-center gap-1"><Clock size={11} /> {formatDate(drop.drop_at, 'MMM d, h:mm a')}</span>
                  <span className="flex items-center gap-1"><Flame size={11} className="text-orange-400" /> {formatNumber(drop.hype_count)} hyped</span>
                </div>
              </div>
              <div className="flex items-start gap-1 flex-shrink-0">
                <button className="w-7 h-7 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400">
                  <Edit2 size={14} />
                </button>
                <button className="w-7 h-7 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400">
                  <MoreHorizontal size={14} />
                </button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ─── Orders Tab ────────────────────────────────────────────

function OrdersTab() {
  return (
    <div>
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: 'Total Orders', value: MOCK_ORDERS.length, icon: ShoppingBag },
          { label: 'Revenue', value: formatCurrency(MOCK_ORDERS.reduce((s, o) => s + o.total, 0)), icon: DollarSign },
          { label: 'Pending', value: MOCK_ORDERS.filter(o => o.status === 'pending' || o.status === 'confirmed').length, icon: Clock },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="bg-white rounded-2xl border border-gray-100 p-4">
            <div className="w-8 h-8 bg-[#F7F0E6] rounded-xl flex items-center justify-center mb-2">
              <Icon size={16} className="text-[#C4622D]" />
            </div>
            <p className="text-xl font-bold text-gray-900">{value}</p>
            <p className="text-xs text-gray-500">{label}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-100 text-xs text-gray-500 uppercase tracking-wide">
              <th className="text-left px-4 py-3 font-semibold">Order</th>
              <th className="text-left px-4 py-3 font-semibold">Customer</th>
              <th className="text-left px-4 py-3 font-semibold">Items</th>
              <th className="text-left px-4 py-3 font-semibold">Total</th>
              <th className="text-left px-4 py-3 font-semibold">Status</th>
              <th className="text-left px-4 py-3 font-semibold">Date</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_ORDERS.map(order => (
              <tr key={order.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                <td className="px-4 py-3 text-sm font-mono text-gray-600">#{order.id.toUpperCase()}</td>
                <td className="px-4 py-3 text-sm text-gray-900 font-medium">{order.customer}</td>
                <td className="px-4 py-3 text-sm text-gray-600">
                  {order.items.map(i => `${i.name} × ${i.qty}`).join(', ')}
                </td>
                <td className="px-4 py-3 text-sm font-semibold text-gray-900">{formatCurrency(order.total)}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-semibold px-2 py-1 rounded-lg capitalize ${STATUS_STYLES[order.status]}`}>
                    {order.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs text-gray-400">{formatDate(order.date, 'MMM d, h:mm a')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Stripe banner */}
      <div className="mt-4 bg-gradient-to-r from-[#1A3A2A] to-[#2D5A40] rounded-2xl p-5 text-white">
        <p className="font-bold text-sm mb-1">Payments via Stripe Connect</p>
        <p className="text-xs text-white/70 mb-3">All payments go directly to your Stripe account. Kitakakis takes a 2% platform fee.</p>
        <button className="bg-white text-[#1A3A2A] text-xs font-bold px-4 py-2 rounded-xl">Connect Stripe Account</button>
      </div>
    </div>
  )
}

// ─── Main Store Page ────────────────────────────────────────

export default function StorePage() {
  const [activeTab, setActiveTab] = useState('products')

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Store</h1>
          <p className="text-sm text-gray-500">Manage products, schedule drops, track orders.</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-6">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-1.5 px-5 py-3 text-sm font-semibold border-b-2 transition-all ${
              activeTab === id
                ? 'border-[#C4622D] text-[#C4622D]'
                : 'border-transparent text-gray-400 hover:text-gray-600'
            }`}
          >
            <Icon size={16} />
            {label}
          </button>
        ))}
      </div>

      {activeTab === 'products' && <ProductsTab />}
      {activeTab === 'drops' && <DropsTab />}
      {activeTab === 'orders' && <OrdersTab />}
    </div>
  )
}
