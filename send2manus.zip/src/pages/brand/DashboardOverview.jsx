import { Link } from 'react-router-dom'
import { TrendingUp, TrendingDown, Users, Eye, ShoppingBag, DollarSign, Sparkles, ArrowRight, CheckCircle, AlertCircle } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts'
import { MOCK_ANALYTICS, MOCK_POSTS } from '../../data/mockData'
import { formatNumber, formatCurrency, formatRelativeTime } from '../../lib/utils'
import { PlatformBadge } from '../../components/shared/Badge'

function StatCard({ label, value, delta, icon: Icon, prefix = '', isCurrency = false }) {
  const isPositive = delta >= 0
  return (
    <div className="bg-white rounded-2xl p-4 border border-gray-100">
      <div className="flex items-start justify-between mb-3">
        <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">{label}</p>
        <div className="w-8 h-8 bg-[#F7F0E6] rounded-xl flex items-center justify-center">
          <Icon size={16} className="text-[#C4622D]" />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 mb-1">
        {isCurrency ? formatCurrency(value) : prefix + formatNumber(value)}
      </p>
      <div className={`flex items-center gap-1 text-xs font-medium ${isPositive ? 'text-green-600' : 'text-red-500'}`}>
        {isPositive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
        <span>{isPositive ? '+' : ''}{delta}{typeof delta === 'number' && delta > 100 ? '' : '%'} this month</span>
      </div>
    </div>
  )
}

function AiRecommendationCard({ rec }) {
  return (
    <div className="bg-gradient-to-br from-[#F7F0E6] to-white border border-[#C4622D]/20 rounded-2xl p-4">
      <div className="flex items-center gap-2 mb-2">
        <Sparkles size={14} className="text-[#C4622D]" />
        <span className="text-xs font-semibold text-[#C4622D] uppercase tracking-wide">AI Recommendation</span>
      </div>
      <p className="text-sm text-gray-800 font-medium mb-1">{rec.title}</p>
      <p className="text-xs text-gray-500">{rec.body}</p>
      <button className="mt-3 text-xs font-semibold text-[#C4622D] flex items-center gap-1">
        Use this <ArrowRight size={12} />
      </button>
    </div>
  )
}

const AI_RECS = [
  {
    title: 'Post between 7–9PM on weekdays',
    body: 'Your audience is most active on Tuesday and Thursday evenings. Engagement is 2.3× higher in this window.',
  },
  {
    title: 'Try a behind-the-scenes video',
    body: 'BTS content for brands like yours averages 68% more saves and 3× shares. Show your process.',
  },
  {
    title: 'Collab opportunity: 3 brands are looking for food & drink partners',
    body: 'Foreword Coffee and 2 others posted open collab listings this week. Check Connect.',
  },
]

export default function DashboardOverview() {
  const { overview, follower_history, platform_breakdown, top_posts } = MOCK_ANALYTICS

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Page header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Overview</h1>
          <p className="text-sm text-gray-500">April 2026 · Assembly Coffee</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 text-xs text-green-600 bg-green-50 px-3 py-1.5 rounded-xl font-medium">
            <CheckCircle size={12} />
            All systems synced
          </span>
          <Link to="/dashboard/content" className="bg-[#C4622D] text-white text-sm font-semibold px-4 py-2 rounded-xl hover:bg-[#a85225] transition-colors">
            + New Post
          </Link>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Followers" value={overview.followers} delta={overview.followers_delta} icon={Users} />
        <StatCard label="Monthly Impressions" value={overview.impressions} delta={overview.impressions_delta} icon={Eye} />
        <StatCard label="Engagement Rate" value={overview.engagement_rate} delta={overview.engagement_delta} icon={TrendingUp} prefix='' />
        <StatCard label="Revenue (MTD)" value={overview.revenue} delta={overview.revenue_delta} icon={DollarSign} isCurrency />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Follower growth */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-5 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <p className="font-semibold text-gray-900">Follower Growth</p>
            <span className="text-xs text-gray-400">Last 30 days</span>
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={follower_history}>
              <defs>
                <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#C4622D" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#C4622D" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={v => v.slice(5)} tickLine={false} axisLine={false} interval={6} />
              <YAxis hide />
              <Tooltip formatter={(v) => [formatNumber(v), 'Followers']} labelFormatter={v => v} contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.1)' }} />
              <Area type="monotone" dataKey="count" stroke="#C4622D" strokeWidth={2} fill="url(#grad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Platform breakdown */}
        <div className="bg-white rounded-2xl p-5 border border-gray-100">
          <p className="font-semibold text-gray-900 mb-4">Platform Breakdown</p>
          <div className="space-y-4">
            {platform_breakdown.map(p => (
              <div key={p.platform}>
                <div className="flex items-center justify-between mb-1.5">
                  <PlatformBadge platform={p.platform} />
                  <span className="text-xs font-semibold text-gray-600">{formatNumber(p.followers)} followers</span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#C4622D] rounded-full"
                    style={{ width: `${(p.followers / overview.followers) * 100}%` }}
                  />
                </div>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-xs text-gray-400">{formatNumber(p.impressions)} impressions</span>
                  <span className="text-xs text-gray-400">{p.engagement}% ER</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top posts */}
        <div className="bg-white rounded-2xl p-5 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <p className="font-semibold text-gray-900">Top Posts This Month</p>
            <Link to="/dashboard/analytics" className="text-xs text-[#C4622D] font-semibold">View all</Link>
          </div>
          <div className="space-y-3">
            {top_posts.map((post, i) => (
              <div key={post.id} className="flex gap-3 items-start">
                <span className="text-lg font-bold text-gray-200 w-6 flex-shrink-0">{i + 1}</span>
                <div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0">
                  {post.media_urls?.[0] && <img src={post.media_urls[0]} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-700 line-clamp-1">{post.content}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <PlatformBadge platform={post.platform} />
                    <span className="text-xs text-gray-400">{formatNumber(post.views)} views</span>
                    <span className="text-xs text-gray-400">{post.likes} ❤️</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI recommendations */}
        <div className="space-y-3">
          {AI_RECS.map(rec => <AiRecommendationCard key={rec.title} rec={rec} />)}
        </div>
      </div>
    </div>
  )
}
